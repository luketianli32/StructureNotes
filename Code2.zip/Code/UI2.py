 

import streamlit as st
import json
import os
import sqlite3
# Load JSON from uploaded file or selected file path
import pandas as pd
import PyPDF2
from docx import Document
from dotenv import load_dotenv
import openai 
       

st.set_page_config(page_title="Structured Note Viewer", layout="wide")
 
client = openai.OpenAI(api_key="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")
#dont share this
 


# === Setup ===
load_dotenv()
 
# File paths (adjust as needed)
CUSTOM_PROMPT = 'Prompts_v2.docx'
KNOWLEDGE_FILE_1 = 'UEQSN_Schema.docx'
KNOWLEDGE_FILE_2 = 'Equity Structured Notes Define Summary.docx'

# === Functions ===
def extract_text_from_pdf(pdf_file):
    text = ""
    try:
        reader = PyPDF2.PdfReader(pdf_file)
        for page in reader.pages:
            text += page.extract_text() or ""
    except Exception as e:
        st.error(f"Failed to read PDF: {e}")
    return text

def read_docx(filepath):
    doc = Document(filepath)
    return "\n".join(p.text for p in doc.paragraphs)

def analyze_with_gpt(text, prompt_path, knowledge_file1, knowledge_file2):
    """Analyze text using GPT with external knowledge from Word documents"""
    try:
        custom_prompt = read_docx(prompt_path)
        knowledge1 = read_docx(knowledge_file1)
        knowledge2 = read_docx(knowledge_file2)
        # custom_prompt =  read_text(prompt_path)
        # knowledge1 = read_text(knowledge_file1)
        # knowledge2 = read_text(knowledge_file2)

        messages = [
            {"role": "system", "content": custom_prompt},
            {"role": "user", "content": "Reference Document 1:\n" + knowledge1},
            {"role": "user", "content": "Reference Document 2:\n" + knowledge2},
            {"role": "user", "content": f"{custom_prompt}\n\nDocument Text:\n{text}"}
        ]
 
        response = client.chat.completions.create(
            model=  "gpt-4o",
            messages=[
                {"role": "system", "content": "You are a financial analyst specializing in structured notes."},
                {"role": "user", "content": f"{custom_prompt}\n\nDocument Text:\n{text}"}
            ],
            temperature=0.1,
            max_tokens=5000
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"OpenAI API error: {str(e)}")
        return None

# === Streamlit UI ===
st.title("📄 Structured Note PDF Uploader & Analyzer")

# Upload section



 
def display_basic_info(data, exclude_keys):
    st.subheader("📋 Meta Information")
    for key, value in data.items():
        if key in exclude_keys:
            continue

        # Skip empty, None, or blank values
        if value is None or (isinstance(value, str) and value.strip() == ""):
            continue

        # Format Notional with commas
        if key == "Notional":
            try:
                value = f"{int(value):,}"
            except:
                pass

        # Style: Larger font, yellow value
        st.markdown(
            f"""
            <div style='font-size:18px; margin-bottom:6px;'>
                <strong>{key}:</strong>
                <span style='color:yellow;'>{value}</span>
            </div>
            """,
            unsafe_allow_html=True
        )





# Display list data as tables
def display_list(key, data_list):
    st.subheader(f"📆 {key}")
    if isinstance(data_list, str):
        st.markdown(data_list,
                unsafe_allow_html=True)
    else:
        st.dataframe(data_list)

def display_underlying_assets(assets,ref):
    st.subheader("📈 Underlying Assets")

    if isinstance(assets, list):
        # Check if list of dictionaries
        if all(isinstance(item, dict) for item in assets):
            if not assets:
                st.markdown("_No underlying asset data available._")
                return

            headers = assets[0].keys()
            rows = [
                    "<tr>" + "".join(
                        f"<td>{'{:,}'.format(value) if isinstance(value, (int, float)) else value}</td>"
                        for value in [item.get(h, '') for h in headers]
                    ) + "</tr>"
                    for item in assets
                ]


            table_html = f"""
            <style>
                .custom-table {{
                    border-collapse: collapse;
                    width: 100%;
                }}
                .custom-table th {{
                    font-size: 18px;
                    text-align: left;
                    padding: 8px;
                    background-color: pink;
                }}
                .custom-table td {{
                    padding: 8px;
                    font-size: 16px;
                    border-top: 1px solid #ddd;
                }}
            </style>
            <table class="custom-table">
                <thead>
                    <tr>{"".join(f"<th>{h}</th>" for h in headers)}</tr>
                </thead>
                <tbody>
                    {''.join(rows)}
                </tbody>
            </table>
            """
            st.markdown(table_html, unsafe_allow_html=True)
        else:
            # List of strings
            for item in assets:
                st.markdown(f"- {item}")
    elif isinstance(assets, str):
        if isinstance(ref, list):
            # Check if list of dictionaries
            if all(isinstance(item, dict) for item in ref):
               

                headers = ref[0].keys()
                rows = [
                        "<tr>" + "".join(
                            f"<td>{'{:,}'.format(value) if isinstance(value, (int, float)) else value}</td>"
                            for value in [item.get(h, '') for h in headers]
                        ) + "</tr>"
                        for item in ref
                    ]


                table_html = f"""
                <style>
                    .custom-table {{
                        border-collapse: collapse;
                        width: 100%;
                    }}
                    .custom-table th {{
                        font-size: 18px;
                        text-align: left;
                        padding: 8px;
                        background-color: pink;
                    }}
                    .custom-table td {{
                        padding: 8px;
                        font-size: 16px;
                        border-top: 1px solid #ddd;
                    }}
                </style>
                <table class="custom-table">
                    <thead>
                        <tr>{"".join(f"<th>{h}</th>" for h in headers)}</tr>
                    </thead>
                    <tbody>
                        {''.join(rows)}
                    </tbody>
                </table>
                """
                st.markdown(table_html, unsafe_allow_html=True)
        else:
            st.markdown(
                f'<div style="font-size:20px; color:yellow; font-weight:bold;">{ref}</div>',
                unsafe_allow_html=True
            )
    else:
        st.markdown("_No underlying asset data available._")



# --- MAIN APP ---

 
 
db_name = 'SN.db'
conn = sqlite3.connect(db_name)
cursor = conn.cursor()
table_name = "SN_data"
df = pd.read_sql_query(f"SELECT * FROM {table_name}", conn)

# Close the connection
conn.close()

with st.sidebar:
    st.header("📁 Load Record from Database")

    # Dropdown to select a SecurityIdentifier
    selected_sid = st.selectbox("Select Security Identifier", df['SecurityIdentifier'].unique())
    uploaded_pdf = st.file_uploader("Upload a Structured Note PDF", type=["pdf"])

# Main area for GPT processing and output
if uploaded_pdf:
    st.info("📤 PDF uploaded. Ready to analyze.")

    if st.button("🔍 Analyze PDF with GPT"):
        try:
            st.info("📝 Extracting text...")
            extracted_text = extract_text_from_pdf(uploaded_pdf)

            st.success("✅ Text extracted. Sending to LLM...")

            with st.spinner("Analyzing with GPT-4..."):
                analysis_result = analyze_with_gpt(extracted_text, CUSTOM_PROMPT, KNOWLEDGE_FILE_1, KNOWLEDGE_FILE_2)

                # Clean up LLM response
                start = analysis_result.find('{')
                end = analysis_result.rfind('}') + 1
                json_str = analysis_result[start:end]
                dv = json.loads(json_str)

                # Remove empty values
                dv = {k: v for k, v in dv.items() if v not in [None, ""] and not (isinstance(v, str) and v.strip() == "")}
                
            if dv:
                st.subheader("🧠 Extracted Structured Note Info")
                st.dataframe(dv, use_container_width=True)

                new_data = {
                    "SecurityIdentifier": uploaded_pdf.name.split(".")[0],
                    "ExtractedText": analysis_result
                }

                # Save to SQLite
                if st.button("💾 Save to Database"):
                    try:
                        conn = sqlite3.connect("SN.db")
                        df_new = pd.DataFrame([new_data])
                        df_new.to_sql("SN_data", conn, if_exists="append", index=False)
                        conn.close()
                        st.success("Data saved to SN.db successfully!")
                    except Exception as e:
                        st.error(f"Error saving to DB: {e}")
        except Exception as e:
            st.error(f"⚠️ Failed to analyze PDF: {e}")


# Filter row by selected SecurityIdentifier
data = None
if selected_sid:
    row = df[df['SecurityIdentifier'] == selected_sid]
    
    if not row.empty:
        # Convert the single row to dictionary
        data = row.iloc[0].to_dict()
        
st.title("📊 Full Dataset Summary")
# Drop rows where UnderlyingAsset is None or NaN
filtered_df = df[df['UnderlyingAsset'].notna() & (df['UnderlyingAsset'].str.strip() != "")]

# Display the filtered dataframe with selected columns
st.dataframe(filtered_df[['SecurityIdentifier', 'Currency', 'SettlementDate', 'Notional','Underlying', 'UnderlyingAsset', 'MaturityDate']])


# === Separator ===
st.markdown("---")
st.header("🔎 Selected Record Details")

# Display content
if data:
    with st.sidebar:
        st.header("🔍 Sections")
        show_sections = {
            "Basic Info": st.checkbox("Basic Info", value=True),
            "Observation Dates": st.checkbox("ObservationDates"),
            "Call Schedule": st.checkbox("CallSchedule"),
            "Call Payment Dates": st.checkbox("CallPaymentDates"),
            "Contingent Payment Dates": st.checkbox("ContingentPaymentDates"),
            "Underlying Assets": st.checkbox("UnderlyingAsset"),
        }

    if show_sections["Basic Info"]:
        exclude = ["ObservationDates", "CallSchedule", "CallPaymentDates", "ContingentPaymentDates", "Underlying", "UnderlyingAsset"]
        display_basic_info(data, exclude)

    if show_sections["Underlying Assets"] and "UnderlyingAsset" in data:
        display_underlying_assets(data["UnderlyingAsset"],data['Underlying'])

    if show_sections["Observation Dates"] and "ObservationDates" in data:
        display_list("Observation Dates", data["ObservationDates"])

    if show_sections["Call Schedule"] and "CallSchedule" in data:
        display_list("Call Schedule", data["CallSchedule"])

    if show_sections["Call Payment Dates"] and "CallPaymentDates" in data:
        display_list("Call Payment Dates", data["CallPaymentDates"])

    if show_sections["Contingent Payment Dates"] and "ContingentPaymentDates" in data:
        display_list("Contingent Payment Dates", data["ContingentPaymentDates"])
